# Kaggle version

Same analysis as the parent folder, with Kaggle's input and output paths.

| File | What it is |
|---|---|
| `breast-np-delivery-ml.ipynb` | The notebook, already executed, with all 7 figures inline. Upload this. |
| `breast-np-delivery-ml.py` | The same code as a script, if you prefer to paste it into a fresh notebook. |
| `data.csv` | The Nano-Tumor Database release, ready to upload as the dataset. |

## Setting it up

1. **Create the dataset.** On Kaggle go to *Datasets → New Dataset*, upload `data.csv`, and title it **`data_set`** so the path matches what the notebook looks for first. Any other title still works — see below.
2. **Create the notebook.** *Code → New Notebook*, then *File → Import Notebook* and pick `breast-np-delivery-ml.ipynb`.
3. **Attach the data.** In the right-hand panel choose *+ Add Input*, find your dataset and add it.
4. **Run it.** *Run All*. It takes roughly 5–6 minutes on a CPU session; no GPU or internet is needed.

## How the data is found

The notebook does not hard-code a single path. It tries, in order:

1. `/kaggle/input/data_set/data.csv`
2. `data/data.csv`, then `data.csv` in the working directory
3. the first `*.csv` under `/kaggle/input/` (so a differently named dataset still works)
4. the authors' GitHub copy, if the session has internet enabled

It then checks the 13 expected columns are present and stops with a clear message if they are not — so a wrong attachment fails immediately rather than part-way through the modelling.

## Output

Figures and tables are written to `/kaggle/working/figures/` and `/kaggle/working/results/`, and the last cell lists them with their sizes. After the run they appear under the *Output* tab, where you can download them or attach them to another notebook.

## Notes

- xgboost, shap and scikit-learn are all in the Kaggle image. The import cell falls back to `pip install` only if you run this somewhere they are missing.
- Internet can stay **off**; it is needed only for the GitHub fallback.
- The run is deterministic. The numbers it produces match the Colab run in the parent folder exactly.
- If you make the notebook public, note that the data is GPL-3.0 from github.com/UFPBPK/Nano-ML-AI and cite Cheng et al. 2020 and Lin et al. 2022 (full references in the parent `README.md`).
