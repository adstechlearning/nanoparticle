# %% [markdown]
# # Machine learning prediction of nanoparticle delivery to breast tumours
# **Data:** Nano-Tumor Database (Cheng et al., *ACS Nano* 2020, 14:3075) as released with
# Lin et al., *Int J Nanomedicine* 2022, 17:1365 (GitHub: UFPBPK/Nano-ML-AI, GPL-3.0).
# 376 nanoparticle (NP) records from 200 mouse studies (2005-2018); delivery efficiency (DE) is the
# % of injected dose reaching the tumour, estimated by a PBPK model.
#
# **Questions**
# 1. Is delivery to breast tumours different from other tumour types?
# 2. Which NP design factors relate to delivery in breast tumour models?
# 3. How well can ML predict DE when tested on *unseen studies* (study-grouped CV) instead of a random split?
# 4. Does a pan-cancer model predict breast-tumour delivery better than a breast-only model?
# 5. What do SHAP explanations say about size, surface charge and targeting for breast tumours?
#
# **Kaggle setup.** Attach the dataset that holds `data.csv` (here: `data_set`) through *+ Add Input*.
# The next cell finds it under `/kaggle/input/` automatically, so no path editing is needed. Figures and
# tables are written to `/kaggle/working/` and appear under *Output* once the notebook finishes.
# xgboost, shap and scikit-learn are already installed in the Kaggle image.
#
# If you are running this somewhere else, it falls back to `data/data.csv` and then to the authors' GitHub copy.

# %%
import os, sys, glob, warnings, json, subprocess
import numpy as np, pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.model_selection import KFold, GroupKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.dummy import DummyRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error
try:
    import xgboost as xgb
    import shap
except ImportError:                                           # not a Kaggle image
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "xgboost", "shap"])
    import xgboost as xgb
    import shap
warnings.filterwarnings("ignore")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 110, "savefig.dpi": 300})
SEED = 42
ON_KAGGLE = os.path.isdir("/kaggle/working")
BASE = "/kaggle/working" if ON_KAGGLE else "."
FIG, RES = f"{BASE}/figures", f"{BASE}/results"
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
print("Running on Kaggle" if ON_KAGGLE else "Running locally", "- outputs go to", os.path.abspath(BASE))
BREAST, OTHER, ACC = "#C2185B", "#9E9E9E", "#1F5F8B"

# %% [markdown]
# ## 1. Load and clean the data

# %%
# List whatever is attached, the usual Kaggle first step
for root, _, files in os.walk("/kaggle/input"):
    for f in files:
        print(os.path.join(root, f))

def find_data():
    """Locate data.csv: attached Kaggle dataset first, then a local copy, then the authors' GitHub release."""
    for p in ("/kaggle/input/data_set/data.csv", "data/data.csv", "data.csv"):
        if os.path.exists(p):
            return p
    hits = sorted(glob.glob("/kaggle/input/**/*.csv", recursive=True))
    if hits:
        return hits[0]
    return "https://raw.githubusercontent.com/UFPBPK/Nano-ML-AI/main/data.csv"

DATA = find_data()
print("Reading:", DATA)
raw = pd.read_csv(DATA)
EXPECTED = {"ID", "Type", "MAT", "TS", "CT", "TM", "Shape", "Size", "ZP", "DE_24", "DE_168", "DE_Max", "DE_Tmax"}
missing = EXPECTED - set(raw.columns)
assert not missing, f"The attached CSV is missing these columns: {sorted(missing)}"
df = raw.copy()
df["CT"] = df["CT"].str.strip().str.capitalize()            # 'skin', 'Skin ' -> 'Skin'
df["Size_nm"] = 10 ** df["Size"]                             # Size is stored as log10(nm)
TM_NAMES = {"AH": "Allograft, heterotopic", "XH": "Xenograft, heterotopic",
            "AO": "Allograft, orthotopic", "XO": "Xenograft, orthotopic", "Other": "Other"}
TARGETS = {"DE_24": "DE at 24 h", "DE_168": "DE at 168 h", "DE_Max": "Maximum DE", "DE_Tmax": "DE at Tmax"}
CATS = ["Type", "MAT", "TS", "CT", "TM", "Shape"]
NUMS = ["Size", "ZP"]
df["is_breast"] = df["CT"].eq("Breast")
print(df.shape, "records;", df.ID.nunique(), "studies")
print("Breast:", df.is_breast.sum(), "records from", df[df.is_breast].ID.nunique(), "studies")
print("Missing zeta potential:", df.ZP.isna().sum())

# %%
def describe(d):
    out = {"Records": len(d), "Studies": d.ID.nunique(),
           "Size, nm (median [IQR])": f"{d.Size_nm.median():.0f} [{d.Size_nm.quantile(.25):.0f}-{d.Size_nm.quantile(.75):.0f}]",
           "Zeta potential, mV (median [IQR])": f"{d.ZP.median():.1f} [{d.ZP.quantile(.25):.1f} to {d.ZP.quantile(.75):.1f}]",
           "Active targeting, n (%)": f"{(d.TS=='Active').sum()} ({100*(d.TS=='Active').mean():.0f}%)",
           "Organic NPs, n (%)": f"{(d.Type=='Organic').sum()} ({100*(d.Type=='Organic').mean():.0f}%)",
           "Spherical, n (%)": f"{(d.Shape=='Spherical').sum()} ({100*(d.Shape=='Spherical').mean():.0f}%)"}
    for t, lab in TARGETS.items():
        out[f"{lab}, %ID (median [IQR])"] = f"{d[t].median():.2f} [{d[t].quantile(.25):.2f}-{d[t].quantile(.75):.2f}]"
    return out
table1 = pd.DataFrame({"Breast tumours": describe(df[df.is_breast]),
                       "Other tumours": describe(df[~df.is_breast]),
                       "All": describe(df)})
table1.to_csv(f"{RES}/Table1_dataset_characteristics.csv")
table1

# %% [markdown]
# ## 2. Breast vs other tumours (Figure 1)

# %%
order = df.groupby("CT").DE_24.median().sort_values(ascending=False).index.tolist()
order = [c for c in order if (df.CT == c).sum() >= 5]
fig, ax = plt.subplots(figsize=(8, 4.2))
data = [df.loc[df.CT == c, "DE_24"] for c in order]
bp = ax.boxplot(data, patch_artist=True, widths=.6, showfliers=False, medianprops=dict(color="k"))
rng = np.random.default_rng(SEED)
for i, (c, y) in enumerate(zip(order, data), 1):
    col = BREAST if c == "Breast" else OTHER
    bp["boxes"][i-1].set(facecolor=col, alpha=.35, edgecolor=col)
    ax.scatter(i + rng.uniform(-.18, .18, len(y)), y, s=9, color=col, alpha=.8, lw=0)
ax.set_yscale("log"); ax.set_ylabel("Delivery efficiency at 24 h (% injected dose)")
ax.set_xticks(range(1, len(order)+1), [f"{c}\n(n={(df.CT==c).sum()})" for c in order], fontsize=8.5)
ax.axhline(df.DE_24.median(), ls="--", lw=.8, color="k"); ax.text(len(order)+.4, df.DE_24.median(), " overall\n median", va="center", fontsize=8)
ax.set_title("Nanoparticle delivery to tumours by cancer type (Nano-Tumor Database)", fontsize=10.5, loc="left")
fig.tight_layout(); fig.savefig(f"{FIG}/Fig1_DE24_by_cancer_type.png"); plt.show()

stat_rows = []
for t in TARGETS:
    u = stats.mannwhitneyu(df.loc[df.is_breast, t], df.loc[~df.is_breast, t])
    stat_rows.append({"Comparison": "Breast vs other tumours", "Endpoint": t,
                      "Breast median": df.loc[df.is_breast, t].median(), "Other median": df.loc[~df.is_breast, t].median(),
                      "Test": "Mann-Whitney U", "Statistic": u.statistic, "p": u.pvalue})

# %% [markdown]
# ## 3. Design factors within breast tumour models (Figure 2)

# %%
B = df[df.is_breast].copy()
fig, axs = plt.subplots(2, 2, figsize=(9, 7))
ax = axs[0, 0]
for ts, col, m in (("Passive", ACC, "o"), ("Active", BREAST, "^")):
    s = B[B.TS == ts]; ax.scatter(s.Size_nm, s.DE_24, color=col, marker=m, s=26, alpha=.75, label=f"{ts} targeting (n={len(s)})", lw=0)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("Hydrodynamic diameter (nm)"); ax.set_ylabel("DE at 24 h (%ID)")
rho = stats.spearmanr(B.Size_nm, B.DE_24); ax.set_title(f"(a) Size  (Spearman ρ = {rho.statistic:.2f}, p = {rho.pvalue:.2g})", fontsize=9.5, loc="left")
ax.legend(fontsize=8, frameon=False)
ax = axs[0, 1]; s = B.dropna(subset=["ZP"])
ax.scatter(s.ZP, s.DE_24, color=ACC, s=26, alpha=.75, lw=0); ax.set_yscale("log"); ax.axvline(0, color="k", lw=.6, ls=":")
ax.set_xlabel("Zeta potential (mV)"); ax.set_ylabel("DE at 24 h (%ID)")
rho2 = stats.spearmanr(s.ZP, s.DE_24); ax.set_title(f"(b) Surface charge  (ρ = {rho2.statistic:.2f}, p = {rho2.pvalue:.2g})", fontsize=9.5, loc="left")

def box(ax, col, title):
    cats = B.groupby(col).DE_24.median().sort_values(ascending=False).index
    cats = [c for c in cats if (B[col] == c).sum() >= 3]
    vals = [B.loc[B[col] == c, "DE_24"] for c in cats]
    b = ax.boxplot(vals, patch_artist=True, showfliers=False, widths=.6, medianprops=dict(color="k"))
    for i, (bx, y) in enumerate(zip(b["boxes"], vals), 1):
        bx.set(facecolor=BREAST, alpha=.3); ax.scatter(i + rng.uniform(-.15, .15, len(y)), y, s=10, color=BREAST, lw=0, alpha=.8)
    ax.set_xticks(range(1, len(cats)+1), [f"{c} ({(B[col]==c).sum()})" for c in cats], fontsize=8, rotation=35, ha="right")
    ax.set_yscale("log"); ax.set_ylabel("DE at 24 h (%ID)"); ax.set_title(title, fontsize=9.5, loc="left")
    return cats, vals
cats, vals = box(axs[1, 0], "MAT", "(c) Core material")
kw = stats.kruskal(*vals); stat_rows.append({"Comparison": "Breast: core material", "Endpoint": "DE_24", "Test": "Kruskal-Wallis", "Statistic": kw.statistic, "p": kw.pvalue})
cats, vals = box(axs[1, 1], "TM", "(d) Tumour model")
axs[1, 1].set_xticks(range(1, len(cats)+1), [f"{TM_NAMES[c]} ({(B.TM==c).sum()})" for c in cats], fontsize=8, rotation=35, ha="right")
kw = stats.kruskal(*vals); stat_rows.append({"Comparison": "Breast: tumour model", "Endpoint": "DE_24", "Test": "Kruskal-Wallis", "Statistic": kw.statistic, "p": kw.pvalue})
u = stats.mannwhitneyu(B.loc[B.TS == "Active", "DE_24"], B.loc[B.TS == "Passive", "DE_24"])
stat_rows.append({"Comparison": "Breast: active vs passive targeting", "Endpoint": "DE_24", "Breast median": B.loc[B.TS=="Active","DE_24"].median(),
                  "Other median": B.loc[B.TS=="Passive","DE_24"].median(), "Test": "Mann-Whitney U (active vs passive)", "Statistic": u.statistic, "p": u.pvalue})
stat_rows.append({"Comparison": "Breast: size", "Endpoint": "DE_24", "Test": "Spearman rho", "Statistic": rho.statistic, "p": rho.pvalue})
stat_rows.append({"Comparison": "Breast: zeta potential", "Endpoint": "DE_24", "Test": "Spearman rho", "Statistic": rho2.statistic, "p": rho2.pvalue})
fig.suptitle("Design factors and delivery efficiency in breast tumour models (108 records, 56 studies)", fontsize=10.5, x=.02, ha="left")
fig.tight_layout(); fig.savefig(f"{FIG}/Fig2_breast_design_factors.png"); plt.show()
stats_df = pd.DataFrame(stat_rows); stats_df.to_csv(f"{RES}/Table2_statistical_tests.csv", index=False)
stats_df.round(4)

# %% [markdown]
# ## 4. Machine learning: random vs study-grouped cross-validation
# Several records often come from the same paper (same lab, mouse strain, dosing and analysis), so a random
# split lets the model "see" a study in training and be tested on its sibling records. Grouping the folds by
# study ID tests generalisation to **new studies**, which is what a NP designer actually needs.
# Targets are log10-transformed (DE is strongly right-skewed); metrics are on the log scale.

# %%
X_all = pd.get_dummies(df[CATS + NUMS], columns=CATS, dtype=float)
FEATS = X_all.columns.tolist()
groups = df["ID"].values

def models():
    return {
        "Mean baseline": DummyRegressor(),
        "Ridge regression": make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler(), Ridge(alpha=3.0)),
        "Random forest": make_pipeline(SimpleImputer(strategy="median", add_indicator=True),
                                       RandomForestRegressor(n_estimators=500, min_samples_leaf=2, max_features=0.5, random_state=SEED, n_jobs=-1)),
        "XGBoost": xgb.XGBRegressor(n_estimators=400, learning_rate=0.03, max_depth=4, subsample=0.8, colsample_bytree=0.8,
                                    min_child_weight=2, reg_lambda=1.0, random_state=SEED, n_jobs=4),
    }

def cv_predict(model, X, y, splitter, groups=None):
    pred = np.empty(len(y))
    for tr, te in splitter.split(X, y, groups):
        m = model; m.fit(X.iloc[tr], y[tr]); pred[te] = m.predict(X.iloc[te])
    return pred

N_REP = 10
rows, oof_store = [], {}
for t in TARGETS:
    y = np.log10(df[t].values)
    for scheme in ("Random 5-fold", "Study-grouped 5-fold"):
        for name, mdl in models().items():
            for r in range(N_REP):
                if scheme.startswith("Random"):
                    p = cv_predict(mdl, X_all, y, KFold(5, shuffle=True, random_state=r))
                else:
                    p = cv_predict(mdl, X_all, y, GroupKFold(5, shuffle=True, random_state=r), groups)
                mb = df.is_breast.values
                rows.append({"Endpoint": t, "CV scheme": scheme, "Model": name, "Repeat": r,
                             "R2 (all)": r2_score(y, p), "RMSE log10 (all)": mean_squared_error(y, p) ** .5,
                             "R2 (breast records)": r2_score(y[mb], p[mb]),
                             "Spearman (breast records)": stats.spearmanr(y[mb], p[mb]).statistic})
                if r == 0: oof_store[(t, scheme, name)] = p
cv = pd.DataFrame(rows)
cv_sum = cv.groupby(["Endpoint", "CV scheme", "Model"]).agg(["mean", "std"]).drop(columns="Repeat").round(3)
cv_sum.columns = [f"{a} {b}" for a, b in cv_sum.columns]
cv_sum.to_csv(f"{RES}/Table3_model_performance_cv.csv")
cv_sum[[c for c in cv_sum.columns if c.startswith("R2")]]

# %% [markdown]
# ### Figure 3: how much performance is lost when the model meets a new study?

# %%
fig, axs = plt.subplots(1, 4, figsize=(11, 3.6), sharey=True)
mnames = ["Ridge regression", "Random forest", "XGBoost"]
for ax, t in zip(axs, TARGETS):
    for j, (scheme, col) in enumerate((("Random 5-fold", "#B0BEC5"), ("Study-grouped 5-fold", ACC))):
        s = cv[(cv.Endpoint == t) & (cv["CV scheme"] == scheme)].groupby("Model")["R2 (all)"]
        m, sd = s.mean()[mnames], s.std()[mnames]
        ax.bar(np.arange(3) + (j - .5) * .38, m, .36, yerr=sd, color=col, capsize=2, label=scheme, edgecolor="none")
    ax.axhline(0, color="k", lw=.6); ax.set_xticks(range(3), ["Ridge", "RF", "XGB"]); ax.set_title(TARGETS[t], fontsize=9.5)
axs[0].set_ylabel("Cross-validated R² (log10 DE)"); axs[0].legend(fontsize=8, frameon=False, loc="upper left")
fig.suptitle("Random vs study-grouped cross-validation (10 repeats, mean ± SD)", fontsize=10.5, x=.02, ha="left")
fig.tight_layout(); fig.savefig(f"{FIG}/Fig3_random_vs_grouped_cv.png"); plt.show()

# %% [markdown]
# ### 4b. Why does performance collapse? Between-study variance (intraclass correlation)
# One-way random-effects ICC(1) of log10 DE with study ID as the grouping factor, using studies that
# contributed >= 2 records. A high ICC means records from the same study resemble each other far more than
# their NP descriptors alone would explain.

# %%
def icc1(values, grp):
    d = pd.DataFrame({"y": values, "g": grp}); d = d[d.groupby("g").y.transform("size") >= 2]
    k = d.groupby("g").size(); n0 = (len(d) - (k**2).sum() / len(d)) / (len(k) - 1)
    gm = d.y.mean(); msb = (k * (d.groupby("g").y.mean() - gm) ** 2).sum() / (len(k) - 1)
    msw = ((d.y - d.groupby("g").y.transform("mean")) ** 2).sum() / (len(d) - len(k))
    return (msb - msw) / (msb + (n0 - 1) * msw), len(k), len(d)
icc_rows = []
for t in TARGETS:
    for lab, m in (("All tumours", np.ones(len(df), bool)), ("Breast tumours", df.is_breast.values)):
        v, ns, nr = icc1(np.log10(df.loc[m, t].values), df.loc[m, "ID"].values)
        icc_rows.append({"Endpoint": t, "Subset": lab, "ICC(1) study": round(v, 3), "Studies (>=2 records)": ns, "Records": nr})
icc = pd.DataFrame(icc_rows); icc.to_csv(f"{RES}/Table3b_between_study_ICC.csv", index=False); icc

# %% [markdown]
# ### 4c. How misleading can a single random 80/20 split be?
# Many published nano-ML studies report one random train/test split. Here the same random forest is
# re-evaluated over 100 different random 80/20 splits on the untransformed DE scale.

# %%
Xf = X_all.fillna(X_all.ZP.median())
split_r2 = {t: [] for t in ("DE_24", "DE_Max")}
for t in split_r2:
    y = df[t].values
    for s in range(100):
        rs = np.random.RandomState(s); te = rs.rand(len(y)) < .2
        m = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, max_features=0.5, random_state=SEED, n_jobs=-1).fit(Xf[~te], y[~te])
        split_r2[t].append(r2_score(y[te], m.predict(Xf[te])))
split_tab = pd.DataFrame({t: pd.Series(v).describe(percentiles=[.05, .5, .95]) for t, v in split_r2.items()}).round(3)
split_tab.to_csv(f"{RES}/Table3c_single_split_variability.csv")
fig, ax = plt.subplots(figsize=(6, 3.2))
ax.hist(split_r2["DE_24"], bins=25, color=ACC, alpha=.85, edgecolor="w")
ax.axvline(np.median(split_r2["DE_24"]), color="k", ls="--", lw=.9)
ax.set_xlabel("Test-set R² (DE at 24 h, untransformed)"); ax.set_ylabel("Number of random splits")
ax.set_title("Same model, same data, 100 different random 80/20 splits", fontsize=10, loc="left")
fig.tight_layout(); fig.savefig(f"{FIG}/FigS1_single_split_variability.png"); plt.show()
split_tab

# %% [markdown]
# ### 4d. Sensitivity: does heavier regularisation rescue study-grouped performance?

# %%
sens = []
y = np.log10(df.DE_24.values)
for lab, mdl in (
    ("XGBoost depth 1", xgb.XGBRegressor(n_estimators=300, learning_rate=0.03, max_depth=1, subsample=.8, colsample_bytree=.8, min_child_weight=5, reg_lambda=5, random_state=SEED)),
    ("XGBoost depth 2", xgb.XGBRegressor(n_estimators=300, learning_rate=0.03, max_depth=2, subsample=.8, colsample_bytree=.8, min_child_weight=5, reg_lambda=5, random_state=SEED)),
    ("XGBoost depth 4 (main)", models()["XGBoost"]),
    ("Random forest leaf 10", make_pipeline(SimpleImputer(strategy="median"), RandomForestRegressor(300, min_samples_leaf=10, max_features=.5, random_state=SEED, n_jobs=-1))),
    ("Random forest leaf 20", make_pipeline(SimpleImputer(strategy="median"), RandomForestRegressor(300, min_samples_leaf=20, max_features=.5, random_state=SEED, n_jobs=-1)))):
    r = [r2_score(y, cv_predict(mdl, X_all, y, GroupKFold(5, shuffle=True, random_state=k), groups)) for k in range(5)]
    sens.append({"Model": lab, "Study-grouped R2 (DE_24) mean": round(np.mean(r), 3), "SD": round(np.std(r, ddof=1), 3)})
sens = pd.DataFrame(sens); sens.to_csv(f"{RES}/Table3d_regularisation_sensitivity.csv", index=False); sens

# %% [markdown]
# ### 4e. Data-quality check: zeta potential recorded as exactly 0 mV
# 43 records (22 breast) report exactly 0 mV, which may mean "neutral" or "not reported". Re-run the key
# analyses treating 0 as missing.

# %%
zp0 = df.ZP.eq(0)
print("ZP == 0:", zp0.sum(), "records,", (zp0 & df.is_breast).sum(), "breast")
X_z = X_all.copy(); X_z.loc[zp0, "ZP"] = np.nan
Bz = B[B.ZP.ne(0)].dropna(subset=["ZP"])
rz = stats.spearmanr(Bz.ZP, Bz.DE_24)
rf = models()["Random forest"]
r_rand = [r2_score(y, cv_predict(rf, X_z, y, KFold(5, shuffle=True, random_state=k))) for k in range(5)]
r_grp = [r2_score(y, cv_predict(rf, X_z, y, GroupKFold(5, shuffle=True, random_state=k), groups)) for k in range(5)]
zp_sens = pd.DataFrame([{"Analysis": "Breast Spearman rho, ZP vs DE_24 (zeros excluded)", "Value": round(rz.statistic, 3), "p / SD": f"{rz.pvalue:.2g}", "n": len(Bz)},
                        {"Analysis": "RF R2 DE_24, random CV (zeros as missing)", "Value": round(np.mean(r_rand), 3), "p / SD": f"{np.std(r_rand, ddof=1):.3f}", "n": len(df)},
                        {"Analysis": "RF R2 DE_24, study-grouped CV (zeros as missing)", "Value": round(np.mean(r_grp), 3), "p / SD": f"{np.std(r_grp, ddof=1):.3f}", "n": len(df)}])
zp_sens.to_csv(f"{RES}/Table3e_zeta_zero_sensitivity.csv", index=False); zp_sens

# %% [markdown]
# ## 5. Pan-cancer vs breast-only models, tested on breast tumours from unseen studies

# %%
def breast_transfer(t, n_rep=N_REP):
    """Predict breast records from studies the model has never seen, training either on breast data alone
    or on the whole database. Both random forest and XGBoost, since they behave differently here."""
    y = np.log10(df[t].values); yb = y[df.is_breast.values]
    b_idx = np.where(df.is_breast.values)[0]; bgroups = groups[b_idx]
    out, last = [], {}
    for mname in ("Random forest", "XGBoost"):
        for r in range(n_rep):
            pb_only, pb_pan = np.empty(len(b_idx)), np.empty(len(b_idx))
            for tr, te in GroupKFold(5, shuffle=True, random_state=r).split(b_idx, groups=bgroups):
                test_ids = set(bgroups[te])
                pb_only[te] = models()[mname].fit(X_all.iloc[b_idx[tr]], y[b_idx[tr]]).predict(X_all.iloc[b_idx[te]])
                pan_tr = np.where(~np.isin(groups, list(test_ids)))[0]      # every record not from a test study
                pb_pan[te] = models()[mname].fit(X_all.iloc[pan_tr], y[pan_tr]).predict(X_all.iloc[b_idx[te]])
            for scope, p in (("Breast-only", pb_only), ("Pan-cancer", pb_pan)):
                out.append({"Endpoint": t, "Training set": scope, "Model": mname, "Repeat": r,
                            "R2": r2_score(yb, p), "RMSE log10": mean_squared_error(yb, p) ** .5,
                            "Spearman": stats.spearmanr(yb, p).statistic,
                            "Within 3-fold (%)": 100 * np.mean(np.abs(yb - p) <= np.log10(3))})
            if r == 0: last[mname] = (yb, pb_only, pb_pan)
    return pd.DataFrame(out), last
tr_all, keep = [], {}
for t in TARGETS:
    d_, keep[t] = breast_transfer(t); tr_all.append(d_)
transfer = pd.concat(tr_all)
transfer_sum = transfer.groupby(["Endpoint", "Model", "Training set"]).agg(["mean", "std"]).drop(columns="Repeat").round(3)
transfer_sum.columns = [f"{a} {b}" for a, b in transfer_sum.columns]
transfer_sum.to_csv(f"{RES}/Table4_breast_only_vs_pan_cancer.csv")
transfer_sum

# %%
fig, axs = plt.subplots(1, 2, figsize=(8.4, 4))
yb, p1, p2 = keep["DE_24"]["Random forest"]
for ax, p, title in ((axs[0], p1, "(a) Breast-only random forest"), (axs[1], p2, "(b) Pan-cancer random forest")):
    ax.scatter(10**yb, 10**p, s=22, color=BREAST, alpha=.75, lw=0)
    lim = [0.005, 80]; ax.plot(lim, lim, "k--", lw=.8)
    ax.fill_between(lim, [l/3 for l in lim], [l*3 for l in lim], color="k", alpha=.06, lw=0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel("Observed DE at 24 h (%ID)"); ax.set_ylabel("Predicted DE at 24 h (%ID)")
    ax.set_title(f"{title}\nR² = {r2_score(yb, p):.2f}, ρ = {stats.spearmanr(yb, p).statistic:.2f}, "
                 f"{100*np.mean(np.abs(yb-p)<=np.log10(3)):.0f}% within 3-fold", fontsize=9.5, loc="left")
fig.suptitle("Breast tumour records predicted from unseen studies (study-grouped CV, random forest, first of 10 repeats)\n"
             "Shaded band = within 3-fold of the observed value; Table 4 reports means over all repeats",
             fontsize=8.5, x=.02, ha="left")
fig.tight_layout(); fig.savefig(f"{FIG}/Fig4_breast_observed_vs_predicted.png"); plt.show()

# %% [markdown]
# ## 6. SHAP explanation of the pan-cancer XGBoost model (DE at 24 h)
# One-hot columns are summed back to their original feature so each design variable gets one SHAP value.

# %%
y24 = np.log10(df.DE_24.values)
final = models()["XGBoost"].fit(X_all, y24)
sv = shap.TreeExplainer(final).shap_values(X_all)
FEAT_LABEL = {"Size": "Size", "ZP": "Zeta potential", "MAT": "Core material", "Type": "Organic/inorganic",
              "TS": "Targeting strategy", "CT": "Cancer type", "TM": "Tumour model", "Shape": "Shape"}
grp = {f: (f if f in NUMS else f.split("_")[0]) for f in FEATS}
S = pd.DataFrame(sv, columns=FEATS).T.groupby(lambda c: grp[c]).sum().T
imp = pd.DataFrame({"All records": S.abs().mean(), "Breast records": S[df.is_breast.values].abs().mean()})
imp = imp.sort_values("Breast records"); imp.index = [FEAT_LABEL[i] for i in imp.index]
imp.round(4).to_csv(f"{RES}/Table5_shap_importance.csv")

fig, axs = plt.subplots(1, 3, figsize=(12, 4), gridspec_kw={"width_ratios": [1.15, 1, 1]})
ax = axs[0]; yy = np.arange(len(imp))
ax.barh(yy + .2, imp["Breast records"], .38, color=BREAST, label="Breast records")
ax.barh(yy - .2, imp["All records"], .38, color=OTHER, label="All records")
ax.set_yticks(yy, imp.index); ax.set_xlabel("Mean |SHAP| (log10 DE units)"); ax.legend(frameon=False, fontsize=8, loc="lower right")
ax.set_title("(a) Feature importance", fontsize=9.5, loc="left")
for ax, f, xl, title, xs in ((axs[1], "Size", "Hydrodynamic diameter (nm)", "(b) Size effect", True),
                             (axs[2], "ZP", "Zeta potential (mV)", "(c) Surface-charge effect", False)):
    xv = df.Size_nm if f == "Size" else df.ZP
    ax.scatter(xv[~df.is_breast], S.loc[~df.is_breast.values, f], s=10, color=OTHER, alpha=.5, lw=0, label="Other tumours")
    ax.scatter(xv[df.is_breast], S.loc[df.is_breast.values, f], s=16, color=BREAST, alpha=.85, lw=0, label="Breast")
    ax.axhline(0, color="k", lw=.6); ax.set_xlabel(xl); ax.set_ylabel(f"SHAP value for {FEAT_LABEL[f].lower()}")
    if xs: ax.set_xscale("log")
    ax.set_title(title, fontsize=9.5, loc="left"); ax.legend(frameon=False, fontsize=8)
fig.suptitle("SHAP explanation of the pan-cancer XGBoost model for DE at 24 h", fontsize=10.5, x=.02, ha="left")
fig.tight_layout(); fig.savefig(f"{FIG}/Fig5_shap.png"); plt.show()
imp

# %% [markdown]
# ## 7. In-silico design map for breast tumours (Figure 6)
# Predicted DE at 24 h for a spherical polymeric NP in an allograft heterotopic (4T1-type) breast model,
# over a size x zeta-potential grid. **Exploratory only:** section 4 shows the model does not generalise to new
# studies, so this map shows what the model has learned, not a validated design rule. Only regions covered by
# real records (white rings) are interpolation.

# %%
sizes = np.logspace(np.log10(10), np.log10(300), 60); zps = np.linspace(-40, 40, 60)
def design_grid(ts):
    g = pd.DataFrame([(np.log10(s), z) for z in zps for s in sizes], columns=["Size", "ZP"])
    for c, v in {"Type": "Organic", "MAT": "Polymeric", "TS": ts, "CT": "Breast", "TM": "AH", "Shape": "Spherical"}.items(): g[c] = v
    Xg = pd.get_dummies(g[CATS + NUMS], columns=CATS, dtype=float).reindex(columns=FEATS, fill_value=0.0)
    return (10 ** final.predict(Xg)).reshape(len(zps), len(sizes))
fig, axs = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
grids = {ts: design_grid(ts) for ts in ("Passive", "Active")}
vmax = max(g.max() for g in grids.values())
for ax, (ts, G) in zip(axs, grids.items()):
    im = ax.pcolormesh(sizes, zps, G, shading="auto", cmap="magma", vmin=0, vmax=vmax)
    ax.set_xscale("log"); ax.set_xlabel("Hydrodynamic diameter (nm)"); ax.set_title(f"{ts} targeting", fontsize=9.5, loc="left")
    pts = B.dropna(subset=["ZP"]); ax.scatter(pts.Size_nm, pts.ZP, s=8, facecolor="none", edgecolor="w", lw=.6)
    i, j = np.unravel_index(G.argmax(), G.shape)
    ax.plot(sizes[j], zps[i], marker="*", ms=12, color="#00E5FF", mec="k")
    ax.set_xlim(sizes[0], sizes[-1]); ax.set_ylim(zps[0], zps[-1])
axs[0].set_ylabel("Zeta potential (mV)")
cb = fig.colorbar(im, ax=axs, shrink=.9); cb.set_label("Predicted DE at 24 h (%ID)")
fig.suptitle("Model-predicted design map: polymeric spheres in a heterotopic allograft breast model (white rings = real breast records)",
             fontsize=9.5, x=.02, ha="left")
fig.savefig(f"{FIG}/Fig6_design_map.png", bbox_inches="tight"); plt.show()
best = {ts: {"size_nm": round(float(sizes[np.unravel_index(G.argmax(), G.shape)[1]]), 1),
             "zeta_mV": round(float(zps[np.unravel_index(G.argmax(), G.shape)[0]]), 1),
             "pred_DE24": round(float(G.max()), 2), "pred_DE24_min": round(float(G.min()), 2)} for ts, G in grids.items()}
json.dump(best, open(f"{RES}/design_map_optimum.json", "w"), indent=1); best

# %% [markdown]
# ## 8. Key numbers for the write-up

# %%
def g(t, scheme, model, col="R2 (all)"):
    s = cv[(cv.Endpoint == t) & (cv["CV scheme"] == scheme) & (cv.Model == model)][col]
    return f"{s.mean():.2f} ± {s.std():.2f}"
key = {
    "records/studies": f"{len(df)}/{df.ID.nunique()}; breast {df.is_breast.sum()}/{df[df.is_breast].ID.nunique()}",
    "median DE24 breast vs other": f"{df.loc[df.is_breast,'DE_24'].median():.2f} vs {df.loc[~df.is_breast,'DE_24'].median():.2f} %ID",
    "breast vs other p (DE24)": f"{stats_df.iloc[0]['p']:.3g}",
}
for t in TARGETS:
    for m in ("Random forest", "XGBoost"):
        key[f"{t} {m} R2 random"] = g(t, "Random 5-fold", m)
        key[f"{t} {m} R2 grouped"] = g(t, "Study-grouped 5-fold", m)
for t in TARGETS:
    for (m, sc), s in transfer[transfer.Endpoint == t].groupby(["Model", "Training set"]):
        key[f"{t} {m}/{sc} breast R2 / rho / within3x"] = (
            f"{s.R2.mean():.3f} ± {s.R2.std():.3f} / {s.Spearman.mean():.2f} / {s['Within 3-fold (%)'].mean():.0f}%")
key["ICC study (DE_24 all / breast)"] = " / ".join(f"{v:.2f}" for v in icc[icc.Endpoint == "DE_24"]["ICC(1) study"])
key["single 80/20 split R2 DE_24: median [5th-95th pct]"] = (f"{np.median(split_r2['DE_24']):.2f} "
    f"[{np.percentile(split_r2['DE_24'], 5):.2f} to {np.percentile(split_r2['DE_24'], 95):.2f}]")
key["ZP==0 sensitivity (breast rho; RF random R2; RF grouped R2)"] = "; ".join(str(v) for v in zp_sens.Value)
key["best regularised grouped R2 DE_24"] = f"{sens['Study-grouped R2 (DE_24) mean'].max():.3f}"
key["top SHAP features (breast)"] = ", ".join(imp.sort_values("Breast records", ascending=False).index[:4])
json.dump(key, open(f"{RES}/key_numbers.json", "w"), indent=1)
for k, v in key.items(): print(f"{k:55s} {v}")

# %% [markdown]
# ## 9. Files written
# Everything below appears in the notebook's **Output** tab and can be downloaded or attached to another notebook.

# %%
for d in (FIG, RES):
    for f in sorted(os.listdir(d)):
        print(f"{d}/{f}  ({os.path.getsize(os.path.join(d, f))/1024:.0f} KB)")
